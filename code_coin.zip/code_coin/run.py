import datetime
import os
import pprint
import time
import threading
import torch as th
from types import SimpleNamespace as SN
from utils.timehelper import time_left, time_str
from os.path import dirname, abspath

from learners import REGISTRY as le_REGISTRY
from runners import REGISTRY as r_REGISTRY
from controllers import REGISTRY as mac_REGISTRY
from components.episode_buffer import ReplayBuffer
from components.transforms import OneHot
import wandb

def run(args, env):

    # Run and train
    run_sequential(args=args, env=env)
    # Clean up after finishing
    print("Exiting Main")

def test(args, env):

    # Run and train
    test_sequential(args=args, env=env)
    # Clean up after finishing
    print("Exiting Main")


def test_once(args, env):

    # Run and train
    test_sequential_once(args=args, env=env)
    # Clean up after finishing
    print("Exiting Main")

def evaluate_sequential(args, runner):

    for _ in range(args.test_nepisode):
        runner.run(test_mode=True)


def run_imit(args, env):
    # Init runner so we can get env info
    runner = r_REGISTRY['imit'](args=args, env=env)

    # Set up schemes and groups here
    env_info = runner.get_env_info()
    args.n_agents = env_info["n_agents"]
    args.n_actions = env_info["n_actions"]
    args.state_shape = env_info["state_shape"]

    # Default/Base scheme
    scheme = {
        "state": {"vshape": env_info["state_shape"]},
        "obs": {"vshape": env_info["obs_shape"], "group": "agents"},
        "actions": {"vshape": (1,), "group": "agents", "dtype": th.long},
        "avail_actions": {
            "vshape": (env_info["n_actions"],),
            "group": "agents",
            "dtype": th.int,
        },
        "reward": {"vshape": (1,)},
        "terminated": {"vshape": (1,), "dtype": th.uint8},
    }
    groups = {"agents": args.n_agents}
    preprocess = {"actions": ("actions_onehot", [OneHot(out_dim=args.n_actions)])}
    buffer = ReplayBuffer(
        scheme,
        groups,
        args.buffer_size,
        env_info["episode_limit"] + 1,
        preprocess=preprocess,
        device="cpu",
    )

    # Setup multiagent controller here
    mac = mac_REGISTRY['imit_mac'](buffer.scheme, groups, env, args)

    # Give runner the scheme
    runner.setup(scheme=scheme, groups=groups, preprocess=preprocess, mac=mac)

    # start training
    episode = 0
    last_test_T = -args.test_interval - 1

    # episode_batch, eval_dict = runner.run(test_mode=True, only_once=True)
    episode_batch, eval_dict = runner.run(test_mode=True,)
    wandb.log(eval_dict, 10000)



def run_sequential(args, env):

    # Init runner so we can get env info
    runner = r_REGISTRY['episode'](args=args, env=env)

    # Set up schemes and groups here
    env_info = runner.get_env_info()
    args.n_agents = env_info["n_agents"]
    args.n_actions = env_info["n_actions"]
    args.state_shape = env_info["state_shape"]

    # Default/Base scheme
    scheme = {
        "state": {"vshape": env_info["state_shape"]},
        "obs": {"vshape": env_info["obs_shape"], "group": "agents"},
        "actions": {"vshape": (1,), "group": "agents", "dtype": th.long},
        "avail_actions": {
            "vshape": (env_info["n_actions"],),
            "group": "agents",
            "dtype": th.int,
        },
        "reward": {"vshape": (1,)},
        "constraint_reward":{"vshape": (1,)},
        "terminated": {"vshape": (1,), "dtype": th.uint8},
    }
    groups = {"agents": args.n_agents}
    preprocess = {"actions": ("actions_onehot", [OneHot(out_dim=args.n_actions)])}
    buffer = ReplayBuffer(
        scheme,
        groups,
        args.buffer_size,
        env_info["episode_limit"] + 1,
        preprocess=preprocess,
        device="cpu",
    )

    # Setup multiagent controller here
    mac = mac_REGISTRY[args.mac](buffer.scheme, groups, args)

    # Give runner the scheme
    runner.setup(scheme=scheme, groups=groups, preprocess=preprocess, mac=mac)

    # Learner
    learner = le_REGISTRY[args.learner](mac, buffer.scheme, args)

    learner.cuda()

    # start training
    episode = 0
    last_test_T = -args.test_interval - 1

    while runner.t_env <= args.t_max:
        # Run for a whole episode at a time
        episode_batch, train_dict = runner.run(test_mode=False)
        buffer.insert_episode_batch(episode_batch)
        wandb.log(train_dict, episode)
        if buffer.can_sample(args.batch_size):
            episode_sample = buffer.sample(args.batch_size)

            # Truncate batch to only filled timesteps
            max_ep_t = episode_sample.max_t_filled()
            episode_sample = episode_sample[:, :max_ep_t]

            if episode_sample.device != args.device:
                episode_sample.to(args.device)

            learn_dict = learner.train(episode_sample, runner.t_env, episode)
            wandb.log(learn_dict, episode)


        # Execute test runs once in a while
        n_test_runs = 1
        if (runner.t_env - last_test_T) / args.test_interval >= 1.0:
            episode_batch, eval_dict = runner.run(test_mode=True)
            buffer.insert_episode_batch(episode_batch)
            if args.primal_dual:
                constraint_value = learner.dual_learn(episode_batch)
                eval_dict['constraint_value'] = constraint_value
            last_test_T = runner.t_env
            wandb.log(eval_dict, episode)

        if episode % 20 == 0:
            mac.save_models(wandb.run.dir, f"ep{episode}")
        episode += 1

def test_sequential(args, env):

    # Init runner so we can get env info
    runner = r_REGISTRY['episode'](args=args, env=env)

    # Set up schemes and groups here
    env_info = runner.get_env_info()
    args.n_agents = env_info["n_agents"]
    args.n_actions = env_info["n_actions"]
    args.state_shape = env_info["state_shape"]

    # Default/Base scheme
    scheme = {
        "state": {"vshape": env_info["state_shape"]},
        "obs": {"vshape": env_info["obs_shape"], "group": "agents"},
        "actions": {"vshape": (1,), "group": "agents", "dtype": th.long},
        "avail_actions": {
            "vshape": (env_info["n_actions"],),
            "group": "agents",
            "dtype": th.int,
        },
        "reward": {"vshape": (1,)},
        "constraint_reward":{"vshape": (1,)},
        "terminated": {"vshape": (1,), "dtype": th.uint8},
    }
    groups = {"agents": args.n_agents}
    preprocess = {"actions": ("actions_onehot", [OneHot(out_dim=args.n_actions)])}
    buffer = ReplayBuffer(
        scheme,
        groups,
        args.buffer_size,
        env_info["episode_limit"] + 1,
        preprocess=preprocess,
        device="cpu",
    )

    # Setup multiagent controller here
    mac = mac_REGISTRY[args.mac](buffer.scheme, groups, args)

    # Give runner the scheme
    runner.setup(scheme=scheme, groups=groups, preprocess=preprocess, mac=mac)
    mac.load_models(args.model_dir, f"ep{args.model_episode}")
    # start training
    episode = 0
    last_test_T = -args.test_interval - 1

        # Run for a whole episode at a time
    n_test_runs = 1
    # if (runner.t_env - last_test_T) / args.test_interval >= 1.0:
    episode_batch, eval_dict = runner.run(test_mode=True)
    last_test_T = runner.t_env
    wandb.log(eval_dict, 0)

    episode += 1



def test_sequential_once(args, env):

    # Init runner so we can get env info
    runner = r_REGISTRY['episode'](args=args, env=env)

    # Set up schemes and groups here
    env_info = runner.get_env_info()
    args.n_agents = env_info["n_agents"]
    args.n_actions = env_info["n_actions"]
    args.state_shape = env_info["state_shape"]

    # Default/Base scheme
    scheme = {
        "state": {"vshape": env_info["state_shape"]},
        "obs": {"vshape": env_info["obs_shape"], "group": "agents"},
        "actions": {"vshape": (1,), "group": "agents", "dtype": th.long},
        "avail_actions": {
            "vshape": (env_info["n_actions"],),
            "group": "agents",
            "dtype": th.int,
        },
        "reward": {"vshape": (1,)},
        "constraint_reward":{"vshape": (1,)},
        "terminated": {"vshape": (1,), "dtype": th.uint8},
    }
    groups = {"agents": args.n_agents}
    preprocess = {"actions": ("actions_onehot", [OneHot(out_dim=args.n_actions)])}
    buffer = ReplayBuffer(
        scheme,
        groups,
        args.buffer_size,
        env_info["episode_limit"] + 1,
        preprocess=preprocess,
        device="cpu",
    )

    # Setup multiagent controller here
    mac = mac_REGISTRY[args.mac](buffer.scheme, groups, args)

    # Give runner the scheme
    runner.setup(scheme=scheme, groups=groups, preprocess=preprocess, mac=mac)
    mac.load_models(args.model_dir, f"ep{args.model_episode}")
    # start training
    episode = 0
    last_test_T = -args.test_interval - 1

        # Run for a whole episode at a time
    n_test_runs = 1
    if (runner.t_env - last_test_T) / args.test_interval >= 1.0:
        episode_batch, eval_dict = runner.run_once(test_mode=True)
        last_test_T = runner.t_env

    episode += 1


def run_imit_once(args, env):
    # Init runner so we can get env info
    runner = r_REGISTRY['imit'](args=args, env=env)

    # Set up schemes and groups here
    env_info = runner.get_env_info()
    args.n_agents = env_info["n_agents"]
    args.n_actions = env_info["n_actions"]
    args.state_shape = env_info["state_shape"]

    # Default/Base scheme
    scheme = {
        "state": {"vshape": env_info["state_shape"]},
        "obs": {"vshape": env_info["obs_shape"], "group": "agents"},
        "actions": {"vshape": (1,), "group": "agents", "dtype": th.long},
        "avail_actions": {
            "vshape": (env_info["n_actions"],),
            "group": "agents",
            "dtype": th.int,
        },
        "reward": {"vshape": (1,)},
        "terminated": {"vshape": (1,), "dtype": th.uint8},
    }
    groups = {"agents": args.n_agents}
    preprocess = {"actions": ("actions_onehot", [OneHot(out_dim=args.n_actions)])}
    buffer = ReplayBuffer(
        scheme,
        groups,
        args.buffer_size,
        env_info["episode_limit"] + 1,
        preprocess=preprocess,
        device="cpu",
    )

    # Setup multiagent controller here
    mac = mac_REGISTRY['imit_mac'](buffer.scheme, groups, env, args)

    # Give runner the scheme
    runner.setup(scheme=scheme, groups=groups, preprocess=preprocess, mac=mac)

    # start training
    episode = 0
    last_test_T = -args.test_interval - 1

    # episode_batch, eval_dict = runner.run(test_mode=True, only_once=True)
    episode_batch, eval_dict = runner.run_once(test_mode=True,)
    # wandb.log(eval_dict, 10000)
