from datetime import datetime
import numpy as np
import time
import torch
import torch.nn as nn
from torch.optim import Adam

from safety_layer.constraint_model import ConstraintModel
from safety_layer.utils import Memory
import wandb
import os


class SafetyLayer:
    def __init__(self, env, args):
        self.env = env
        # set attributes
        self.args = args
        self.batch_size = args.batch_size
        self.lr = args.lr_safe
        self.epochs = 20
        self.training_steps_per_epoch = 1
        self.evaluation_steps_per_epoch = 24
        self.memory_buffer_size = 100000
        self.sample_data_episodes = 100
        self.correction_scale = 5.0
        self.action_low = 0.3
        self.action_high = 1.0
        # init constraint model
        state_dim = sum(args.obs_shape)
        action_dim = sum(args.action_shape)
        self.model = ConstraintModel(args).cuda()
        self.optim = Adam(self.model.parameters(), lr=self.lr)
                       
        # use doubles for calculations
        self.model.double()
        # Mean-Squared-Error as loss criterion
        self.loss_criterion = nn.MSELoss()
        # init memory
        self.memory = Memory(self.memory_buffer_size)
        # Tensorboard writer
        self.train_step = 0
        self.eval_step = 0

    def set_train_mode(self):
        self.model.train()

    def set_eval_mode(self):
        self.model.eval()

    def _sample_steps(self, episodes):
        # sample episodes and push to memory
        for _ in range(episodes):
            # state = self.env.reset(random_agent_position=True)
            state = self.env.reset()
            print('reset')
            # constraints = self.env.get_constraint_values()
            # ball position < 1 - slack --> ball position - (1 - slack) < 0
            max_constraints = self.env.get_constraint_values()

            mydone = False
            time_step = 0
            r_global_n = [0]
            while not mydone:
                # get random action
                
                action = []
                for action_space in self.env.action_space:
                    action.append(action_space.sample())
                # apply action
                next_state, r, done, info ,remain_core_n,  vm_satisfied_core_n, vm_unsatisfied_core_n,node_satisfied_core_n,node_unsatisfied_core_n,r_local_n,r_global_n,remain_core_normalized_n,vm_satisfied_normalized_n, _r_local1, _r_local2, _sum_nodes_overused, _max_nodes_overused = self.env.step(action, time_step, 0, True)
                # get changed constraint values
                # next_constraints = self.env.get_constraint_values()
                next_max_constraints = self.env.get_constraint_values()
                # push to memory
                self.memory.push(state, action, max_constraints, next_max_constraints)
                state = next_state
                constraints = next_max_constraints
                time_step += 1
                if done[0]==0 or time_step >= 24: 
                    mydone = True 

    def _calc_loss(self, model, states, actions, constraints, next_constraints):
        # calculate batch-dot-product via torch.einsum
        # import pdb; pdb.set_trace()
        # model.cuda()
        gi = model.forward(states)
        actions = actions.squeeze()
        predicted_constraints = constraints + \
            torch.einsum('ij,ij->i', gi, actions)
        # alternative: calculate batch-dot-product via torch.bmm
        # gi = model.forward(states).unsqueeze(1)
        # actions = actions.unsqueeze(1)
        # predicted_constraints = constraints + torch.bmm(gi, actions.transpose(1,2)).squeeze(1).squeeze(1)

        # alternative loss calculation
        # loss = (next_constraints - predicted_constraints) ** 2
        # return torch.mean(loss)
        loss = self.loss_criterion(next_constraints, predicted_constraints)
        return loss

    def _update_batch(self, batch):
        states, actions, constraints, next_constraints = batch
        states = torch.DoubleTensor(states).cuda()
        actions = torch.DoubleTensor(actions).cuda()
        constraints = torch.DoubleTensor(constraints).cuda()
        next_constraints = torch.DoubleTensor(next_constraints).cuda()

        losses = []
    
            # calculate loss
        loss = self._calc_loss(
            self.model, states, actions, constraints, next_constraints)
        losses.append(loss.item())
        # zero gradients
        self.optim.zero_grad()
        # backward pass
        loss.backward()
        # update optimizer
        self.optim.step()

        return loss

    def _evaluate_batch(self, batch):
        states, actions, constraints, next_constraints = batch
        states = torch.DoubleTensor(states).cuda()
        actions = torch.DoubleTensor(actions).cuda()
        constraints = torch.DoubleTensor(constraints).cuda()
        next_constraints = torch.DoubleTensor(next_constraints).cuda()

        losses = []
            # compute losses
        loss = self._calc_loss(
            self.model, states, actions, constraints, next_constraints)
        losses.append(loss.item())

        return np.array(losses)

    def train(self):
        start_time = time.time()

        print("==========================================================")
        print("Initializing constraint model training...")
        print("----------------------------------------------------------")
        print(f"Start time: {datetime.fromtimestamp(start_time)}")
        print("==========================================================")

        # sample random action episodes and store them in memory
        self._sample_steps(self.sample_data_episodes)
        print('Sample Done')
        for epoch in range(self.epochs):
            # training phase
            self.set_train_mode()
            losses = []
            for _ in range(self.training_steps_per_epoch):
                batch = self.memory.sample(self.batch_size)
                loss = self._update_batch(batch).item()
                losses.append(loss)
            # print(
            #     f"Finished epoch {epoch} with average loss: {np.mean(losses, axis=0)}. Running evaluation ...")
            # # log training losses to tensorboard
            # for i, loss in enumerate(np.mean(losses, axis=0)):
            #     print(
            #         f"constraints/constraint {i}/training loss", loss, self.train_step)
            print(f'loss in epoch {epoch} is {np.array(losses).mean()}')
            train_loss = np.array(losses).mean()
            self.train_step += 1

            # evaluation phase
            self.set_eval_mode()
            losses = []
            for _ in range(self.evaluation_steps_per_epoch):
                batch = self.memory.sample(self.batch_size)
                loss = self._evaluate_batch(batch).item()
                losses.append(loss)

            val_loss = np.mean(losses, axis=0)
            wandb.log({'train_loss': train_loss, 
            'val_loss':val_loss}, epoch)
            print(
                f"Evaluation completed, average loss {val_loss}")
            # log evaluation losses to tensorboard
            print(
                f"constraints eval loss {losses[0]}, {self.eval_step})")
            self.eval_step += 1
            print("----------------------------------------------------------")

        print("==========================================================")
        print(
            f"Finished training constraint model. Time spent: {(time.time() - start_time) // 1} secs")
        print("==========================================================")
        self.save_model()

    def get_safe_action(self, state, action, constraints):
        self.set_eval_mode()

        state = torch.DoubleTensor(state).cuda()
        action = torch.DoubleTensor(action).cuda()
        action = action.reshape(-1).cuda()
        constraint = torch.DoubleTensor(constraints)[0].cuda()

        g = self.model.forward(state)[0]
        # calculate lagrange multipliers
        
        multipliers = torch.clip((torch.dot(
            g, action) + constraint) / torch.dot(g, g), min=0)
        # Calculate correction; scale correction to be more agressive
        safe_action = action - multipliers * g * self.correction_scale
        safe_action = safe_action.data.detach().cpu().numpy()
        safe_action = np.clip(safe_action, self.action_low, self.action_high)

        return safe_action.reshape(-1, 1)

    # def predict_constraints(self, state, action, constraints):
    #     state = torch.DoubleTensor(state)
    #     action = torch.DoubleTensor(action)
    #     constraints = torch.DoubleTensor(constraints)

    #     g = [model.forward(state) for model in self.models]
    #     # calculate lagrange multipliers
    #     pred_constraints = [(torch.dot(gi, action) + ci) for gi, ci in zip(g, constraints)]
    #     pred_constraints = [ci.data.detach().numpy() for ci in pred_constraints]
    #     return pred_constraints
    def save_model(self):
        model_path = os.path.join(self.args.save_dir, str(self.args.max_usage))
        if not os.path.exists(model_path):
            os.makedirs(model_path)
        torch.save(self.model.state_dict(), model_path + '/' 'safe_layer.pkl')

    
    def load_model(self):
        model_path = os.path.join(self.args.save_dir, str(self.args.max_usage))
        state_dict = torch.load(model_path + '/' + 'safe_layer.pkl')
        self.model.load_state_dict(state_dict)
        self.model.cuda()