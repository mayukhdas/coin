import torch
import torch.nn as nn
import torch.nn.functional as F


# define the actor network
class ConstraintModel(nn.Module):
    def __init__(self, args):
        super(ConstraintModel, self).__init__()
        self.fc1 = nn.Linear(sum(args.obs_shape), 64)
        self.fc2 = nn.Linear(64, 64)
        self.fc3 = nn.Linear(64, 64)
        self.action_out = nn.Linear(64, sum(args.action_shape))

    def forward(self, x):
        x = x.reshape(x.shape[0], -1)
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = F.relu(self.fc3(x))
        actions = self.action_out(x)
        
        # actions = self.max_action * torch.tanh(self.action_out(x))

        return actions

