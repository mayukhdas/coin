# Coin: Chance-Constrained Imitation Learning for Safe and Adaptive Resource Oversubscription under Uncertainty

## Preparation
Install the related package listed in requirements.txt

## Run experiments
run.py
